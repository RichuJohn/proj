﻿//var app = require("./test.jsx");
////import ReactDOM from "react-dom";
    

//var App = require('test.jsx')

//ReactDOM.render(
//    <App />,
//    document.getElementById('root')
//);
